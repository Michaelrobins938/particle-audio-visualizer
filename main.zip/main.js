

import * as THREE from 'https://unpkg.com/three@0.150.1/build/three.module.js';
import * as dat from 'https://cdn.jsdelivr.net/npm/dat.gui/build/dat.gui.module.js';

// Constants
const CONSTANTS = {
    MAX_PARTICLES: 100000,
    MIN_PARTICLES: 1000,
    MAX_SPHERES: 5,
    AUDIO_FFT_SIZE: 2048,
    NOISE_PERMUTATION_SIZE: 256,
    BEAT_HISTORY_LENGTH: 25,
    MIN_PEAK_INTERVAL: 150,
    ANIMATION_MAX_DELTA: 0.1,
    RESIZE_THROTTLE: 16,
    CLEANUP_DELAY: 100
};

console.log('Audio Visualizer starting...');

class AudioVisualizer {
    constructor() {
        this.scene = null;
        this.camera = null;
        this.renderer = null;
        this.audioContext = null;
        this.analyser = null;
        this.micStream = null;
        this.micSource = null;
        this.gainNode = null;
        this.isAudioInitialized = false;
        this.usingMic = false;
        this.animationId = null;
        this.lastTime = 0;
        this.statusTimeout = null;
        this.controlsVisible = true;
        this.isDestroyed = false;
        this.resizeTimeout = null;
        
        this.spheres = [];
        this.defaultParams = [];
        this.presets = {};
        this.mainGui = null;
        this.elements = {};
        
        this.beatManager = new BeatManager();
        this.noiseGenerator = new NoiseGenerator();
        
        // Bind methods to prevent context loss
        this.animate = this.animate.bind(this);
        this.handleResize = this.handleResize.bind(this);
        this.handleVisibilityChange = this.handleVisibilityChange.bind(this);
        this.handleWebGLContextLost = this.handleWebGLContextLost.bind(this);
        this.handleWebGLContextRestored = this.handleWebGLContextRestored.bind(this);
        
        this.init();
    }

    async init() {
        try {
            if (this.isDestroyed) return;
            
            this.cleanupPreviousElements();
            this.setupStyles();
            this.setupScene();
            this.setupAudio();
            this.setupGUI();
            this.setupEventListeners();
            this.createSpheres();
            this.loadPresets();
            this.updateStatus('Ready - Click "Start Microphone" to begin visualization');
            this.animate();
        } catch (error) {
            console.error('Initialization failed:', error);
            this.updateStatus('Initialization failed - check console for details', true);
        }
    }

    cleanupPreviousElements() {
        const selectors = [
            '#songSelect', '#playPause', '#volume', 'button', 'select', 
            '.dg.main', 'canvas', '.controls-container', '#volumeControl', 
            '#audioControls', '.audio-control', '.audio-controls'
        ];
        
        selectors.forEach(selector => {
            try {
                document.querySelectorAll(selector).forEach(element => {
                    if (selector !== '#presetContainer' && element.parentNode) {
                        element.parentNode.removeChild(element);
                    }
                });
            } catch (error) {
                console.warn(`Failed to remove element ${selector}:`, error);
            }
        });

        // Clean up control divs
        document.querySelectorAll('div').forEach(div => {
            try {
                if ((div.id?.includes('control') || div.className?.includes('control') ||
                    div.id?.includes('audio') || div.className?.includes('audio')) && 
                    div.id !== 'presetContainer' && div.parentNode) {
                    div.parentNode.removeChild(div);
                }
            } catch (error) {
                console.warn('Failed to remove control div:', error);
            }
        });
    }

    setupStyles() {
        const existingStyle = document.getElementById('audio-visualizer-styles');
        if (existingStyle) {
            existingStyle.remove();
        }

        const styles = document.createElement('style');
        styles.id = 'audio-visualizer-styles';
        styles.textContent = `
            body { 
                margin: 0; padding: 0; overflow: hidden; background: #000; 
                font-family: 'Arial', sans-serif; user-select: none;
                touch-action: manipulation;
            }
            canvas { 
                display: block; cursor: pointer; 
                position: fixed; top: 0; left: 0; z-index: 0;
            }
            .dg.main {
                position: fixed !important; top: 10px !important; right: 10px !important;
                z-index: 1000 !important; max-height: calc(100vh - 20px) !important;
                overflow-y: auto !important; max-width: 300px !important;
            }
            #presetContainer {
                position: fixed !important; bottom: 20px !important; left: 20px !important;
                z-index: 1000 !important; display: flex !important; gap: 10px !important;
                background: rgba(0, 0, 0, 0.95); padding: 15px; border-radius: 10px;
                border: 1px solid #333; backdrop-filter: blur(15px);
                box-shadow: 0 8px 32px rgba(0, 0, 0, 0.5); flex-wrap: wrap;
                max-width: calc(100vw - 40px);
            }
            #presetContainer input[type="text"] {
                flex: 1 1 auto; min-width: 150px; padding: 8px; border-radius: 6px;
                background: #111; border: 1px solid #00FFFF; color: #fff;
                font-size: 14px; outline: none;
            }
            #presetContainer select, #presetContainer button {
                flex: 0 0 auto; padding: 8px 12px; border-radius: 6px;
                background: linear-gradient(135deg, #00FFFF, #FF0055); color: #000;
                border: none; font-weight: 600; cursor: pointer;
                transition: all 0.3s ease; font-size: 14px; outline: none;
                touch-action: manipulation;
            }
            #presetContainer button:hover, #presetContainer select:hover {
                transform: translateY(-2px); box-shadow: 0 4px 15px rgba(0, 255, 255, 0.3);
            }
            .audio-controls {
                position: fixed !important; top: 10px !important; left: 10px !important;
                z-index: 1000 !important; background: rgba(0,0,0,0.85); padding: 15px;
                border-radius: 10px; backdrop-filter: blur(10px); border: 1px solid #333;
                display: flex; align-items: center; gap: 10px; flex-wrap: wrap;
                max-width: calc(100vw - 340px);
            }
            .audio-controls button {
                padding: 8px 16px; border-radius: 6px;
                background: linear-gradient(135deg, #00FFFF, #FF0055); color: #000;
                border: none; font-weight: 600; cursor: pointer;
                transition: all 0.3s ease; outline: none;
                touch-action: manipulation; min-width: 44px; min-height: 44px;
            }
            .audio-controls button:hover {
                transform: translateY(-2px); box-shadow: 0 4px 15px rgba(0, 255, 255, 0.3);
            }
            .audio-controls button:disabled {
                opacity: 0.5; cursor: not-allowed; transform: none;
                box-shadow: none;
            }
            .audio-controls input[type="range"] {
                width: 120px; height: 6px; border-radius: 3px; background: #333;
                outline: none; -webkit-appearance: none; touch-action: manipulation;
            }
            .audio-controls input[type="range"]::-webkit-slider-thumb {
                -webkit-appearance: none; width: 18px; height: 18px; border-radius: 50%;
                background: linear-gradient(135deg, #00FFFF, #FF0055); cursor: pointer;
            }
            .audio-controls input[type="range"]::-moz-range-thumb {
                width: 18px; height: 18px; border-radius: 50%;
                background: linear-gradient(135deg, #00FFFF, #FF0055); cursor: pointer;
                border: none;
            }
            .status-indicator {
                position: fixed; top: 10px; left: 50%; transform: translateX(-50%);
                background: rgba(0, 0, 0, 0.9); color: #00FFFF; padding: 8px 16px;
                border-radius: 6px; z-index: 1001; font-size: 14px;
                transition: opacity 0.3s ease; pointer-events: none;
                max-width: calc(100vw - 20px); text-align: center;
                box-sizing: border-box;
            }
            .status-indicator.error {
                color: #FF4444; border: 1px solid #FF4444;
            }
            @media (max-width: 768px) {
                .dg.main { 
                    right: 5px !important; top: 5px !important; 
                    max-width: calc(100vw - 10px) !important;
                }
                .audio-controls { 
                    left: 5px !important; top: 5px !important; 
                    max-width: calc(100vw - 10px) !important;
                    margin-bottom: 10px;
                }
                #presetContainer { 
                    bottom: 5px !important; left: 5px !important; 
                    max-width: calc(100vw - 10px) !important;
                }
                .audio-controls input[type="range"] { width: 80px; }
            }
            @media (max-width: 480px) {
                .audio-controls { flex-direction: column; align-items: stretch; }
                .audio-controls button { margin: 2px 0; }
                #presetContainer { flex-direction: column; }
                #presetContainer input, #presetContainer select, #presetContainer button {
                    width: 100%; margin: 2px 0;
                }
            }
        `;
        document.head.appendChild(styles);
    }

    setupScene() {
        try {
            // Scene
            this.scene = new THREE.Scene();
            this.scene.background = new THREE.Color(0x000000);

            // Camera
            this.camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
            this.camera.position.z = 3;

            // Renderer with enhanced settings
            const rendererOptions = { 
                antialias: window.devicePixelRatio <= 1,
                alpha: true,
                powerPreference: "high-performance",
                failIfMajorPerformanceCaveat: false,
                preserveDrawingBuffer: false,
                premultipliedAlpha: false,
                stencil: false,
                depth: true
            };

            this.renderer = new THREE.WebGLRenderer(rendererOptions);
            this.renderer.setSize(window.innerWidth, window.innerHeight);
            this.renderer.shadowMap.enabled = true;
            this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
            this.renderer.setClearColor(0x000000, 1);
            this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
            this.renderer.outputEncoding = THREE.sRGBEncoding;
            this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
            this.renderer.toneMappingExposure = 1;
            
            // Add WebGL context loss handling
            this.renderer.domElement.addEventListener('webglcontextlost', this.handleWebGLContextLost, false);
            this.renderer.domElement.addEventListener('webglcontextrestored', this.handleWebGLContextRestored, false);
            
            document.body.appendChild(this.renderer.domElement);

            // Status indicator
            this.elements.statusIndicator = document.createElement('div');
            this.elements.statusIndicator.className = 'status-indicator';
            this.elements.statusIndicator.textContent = 'Initializing...';
            document.body.appendChild(this.elements.statusIndicator);

            // Lighting and reflection
            this.setupLighting();
        } catch (error) {
            console.error('Scene setup failed:', error);
            throw error;
        }
    }

    setupLighting() {
        try {
            // Reflection plane
            const planeGeometry = new THREE.PlaneGeometry(20, 20);
            const planeMaterial = new THREE.MeshBasicMaterial({
                color: 0x111111,
                transparent: true,
                opacity: 0.1,
            });

            const reflectionPlane = new THREE.Mesh(planeGeometry, planeMaterial);
            reflectionPlane.rotation.x = -Math.PI / 2;
            reflectionPlane.position.y = -3;
            reflectionPlane.receiveShadow = true;
            this.scene.add(reflectionPlane);

            // Lights
            const ambientLight = new THREE.AmbientLight(0x404040, 0.4);
            this.scene.add(ambientLight);

            const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
            directionalLight.position.set(5, 10, 5);
            directionalLight.castShadow = true;
            directionalLight.shadow.mapSize.width = 2048;
            directionalLight.shadow.mapSize.height = 2048;
            directionalLight.shadow.camera.near = 0.1;
            directionalLight.shadow.camera.far = 50;
            this.scene.add(directionalLight);
        } catch (error) {
            console.error('Lighting setup failed:', error);
        }
    }

    setupAudio() {
        try {
            // Audio controls
            this.elements.audioControls = document.createElement('div');
            this.elements.audioControls.className = 'audio-controls';
            document.body.appendChild(this.elements.audioControls);

            this.elements.micToggle = document.createElement('button');
            this.elements.micToggle.textContent = 'Start Microphone';
            this.elements.micToggle.setAttribute('aria-label', 'Toggle microphone');
            this.elements.audioControls.appendChild(this.elements.micToggle);

            this.elements.gainControl = document.createElement('input');
            this.elements.gainControl.type = 'range';
            this.elements.gainControl.min = '0.1';
            this.elements.gainControl.max = '5';
            this.elements.gainControl.step = '0.1';
            this.elements.gainControl.value = '1';
            this.elements.gainControl.setAttribute('aria-label', 'Audio gain control');
            this.elements.audioControls.appendChild(this.elements.gainControl);

            this.elements.gainLabel = document.createElement('span');
            this.elements.gainLabel.textContent = 'Gain: 1.0x';
            this.elements.gainLabel.style.color = '#fff';
            this.elements.gainLabel.style.fontSize = '14px';
            this.elements.gainLabel.style.whiteSpace = 'nowrap';
            this.elements.audioControls.appendChild(this.elements.gainLabel);
        } catch (error) {
            console.error('Audio setup failed:', error);
        }
    }

    setupGUI() {
        try {
            // Clean up existing GUI
            if (this.mainGui) {
                this.mainGui.destroy();
                this.mainGui = null;
            }

            this.mainGui = new dat.GUI({ autoPlace: true });

            // Fog controls
            this.fogParams = {
                enabled: true,
                color: '#000000',
                near: 2.5,
                far: 4.0,
            };

            this.mainGui.add(this.fogParams, 'enabled').name('Fog Enabled').onChange(() => this.updateFog());
            this.mainGui.addColor(this.fogParams, 'color').name('Fog Color').onChange(() => this.updateFog());
            this.mainGui.add(this.fogParams, 'near', 0.1, 10, 0.1).name('Fog Near').onChange(() => this.updateFog());
            this.mainGui.add(this.fogParams, 'far', 0.1, 10, 0.1).name('Fog Far').onChange(() => this.updateFog());

            // Global controls
            this.mainGui.add({
                globalParticleCount: 25000
            }, 'globalParticleCount', CONSTANTS.MIN_PARTICLES, CONSTANTS.MAX_PARTICLES, 1000)
            .name('Global Particle Count')
            .onChange(value => this.updateGlobalParticleCount(value));

            this.updateFog();

            // Preset controls
            this.setupPresetControls();
        } catch (error) {
            console.error('GUI setup failed:', error);
        }
    }

    setupPresetControls() {
        try {
            // Remove existing preset container
            const existing = document.getElementById('presetContainer');
            if (existing) {
                existing.remove();
            }

            this.elements.presetContainer = document.createElement('div');
            this.elements.presetContainer.id = 'presetContainer';

            this.elements.presetInput = document.createElement('input');
            this.elements.presetInput.type = 'text';
            this.elements.presetInput.placeholder = 'Preset name';
            this.elements.presetInput.setAttribute('aria-label', 'Preset name input');

            this.elements.saveButton = document.createElement('button');
            this.elements.saveButton.textContent = 'Save';
            this.elements.saveButton.setAttribute('aria-label', 'Save preset');

            this.elements.resetButton = document.createElement('button');
            this.elements.resetButton.textContent = 'Reset';
            this.elements.resetButton.setAttribute('aria-label', 'Reset to defaults');

            this.elements.presetSelect = document.createElement('select');
            this.elements.presetSelect.setAttribute('aria-label', 'Select preset');

            this.elements.deleteButton = document.createElement('button');
            this.elements.deleteButton.textContent = 'Delete';
            this.elements.deleteButton.setAttribute('aria-label', 'Delete preset');

            this.elements.exportButton = document.createElement('button');
            this.elements.exportButton.textContent = 'Export';
            this.elements.exportButton.setAttribute('aria-label', 'Export presets');

            this.elements.importButton = document.createElement('button');
            this.elements.importButton.textContent = 'Import';
            this.elements.importButton.setAttribute('aria-label', 'Import presets');

            [this.elements.presetInput, this.elements.saveButton, this.elements.resetButton,
             this.elements.deleteButton, this.elements.exportButton, this.elements.importButton,
             this.elements.presetSelect].forEach(element => {
                this.elements.presetContainer.appendChild(element);
            });

            document.body.appendChild(this.elements.presetContainer);
        } catch (error) {
            console.error('Preset controls setup failed:', error);
        }
    }

    setupEventListeners() {
        try {
            // Audio controls
            this.elements.micToggle.addEventListener('click', () => {
                if (!this.isDestroyed) {
                    this.toggleMicrophone();
                }
            });
            
            this.elements.gainControl.addEventListener('input', (e) => {
                if (!this.isDestroyed) {
                    this.updateGain(e);
                }
            });

            // Preset controls
            this.elements.saveButton.addEventListener('click', () => {
                if (!this.isDestroyed) {
                    this.savePreset();
                }
            });
            
            this.elements.resetButton.addEventListener('click', () => {
                if (!this.isDestroyed) {
                    this.resetToDefaults();
                }
            });
            
            this.elements.deleteButton.addEventListener('click', () => {
                if (!this.isDestroyed) {
                    this.deletePreset();
                }
            });
            
            this.elements.exportButton.addEventListener('click', () => {
                if (!this.isDestroyed) {
                    this.exportPresets();
                }
            });
            
            this.elements.importButton.addEventListener('click', () => {
                if (!this.isDestroyed) {
                    this.importPresets();
                }
            });
            
            this.elements.presetSelect.addEventListener('change', () => {
                if (!this.isDestroyed) {
                    this.loadPreset();
                }
            });

            // Window events with throttling
            let resizeTimeout;
            window.addEventListener('resize', () => {
                if (resizeTimeout) {
                    clearTimeout(resizeTimeout);
                }
                resizeTimeout = setTimeout(() => {
                    if (!this.isDestroyed) {
                        this.handleResize();
                    }
                }, CONSTANTS.RESIZE_THROTTLE);
            });

            // Cleanup events
            window.addEventListener('beforeunload', () => this.cleanup());
            window.addEventListener('unload', () => this.cleanup());
            
            // Visibility change handling
            document.addEventListener('visibilitychange', this.handleVisibilityChange);

            // Click to toggle controls
            document.addEventListener('click', (event) => {
                if (!this.isDestroyed) {
                    this.handleDocumentClick(event);
                }
            });

            // Keyboard shortcuts
            document.addEventListener('keydown', (event) => {
                if (!this.isDestroyed) {
                    this.handleKeyboard(event);
                }
            });
        } catch (error) {
            console.error('Event listeners setup failed:', error);
        }
    }

    updateFog() {
        try {
            if (!this.scene) return;
            
            if (!this.fogParams.enabled) {
                this.scene.fog = null;
            } else {
                const color = new THREE.Color(this.fogParams.color);
                this.scene.fog = new THREE.Fog(color, this.fogParams.near, this.fogParams.far);
            }
        } catch (error) {
            console.error('Failed to update fog:', error);
        }
    }

    updateGlobalParticleCount(value) {
        try {
            if (!this.spheres || this.isDestroyed) return;
            
            const validValue = Math.max(CONSTANTS.MIN_PARTICLES, Math.min(value, CONSTANTS.MAX_PARTICLES));
            
            this.spheres.forEach((sphere, index) => {
                if (!sphere?.params) return;
                
                sphere.params.particleCount = validValue;
                this.reinitializeParticles(sphere);

                const sphereFolder = this.mainGui.__folders[`Sphere ${index + 1}`];
                if (sphereFolder) {
                    const controller = sphereFolder.__controllers.find(c => c.property === 'particleCount');
                    if (controller) controller.updateDisplay();
                }
            });
        } catch (error) {
            console.error('Failed to update global particle count:', error);
        }
    }

    updateStatus(message, temporary = false, isError = false) {
        try {
            if (this.statusTimeout) {
                clearTimeout(this.statusTimeout);
                this.statusTimeout = null;
            }
            
            if (!this.elements.statusIndicator) return;
            
            this.elements.statusIndicator.textContent = message;
            this.elements.statusIndicator.style.opacity = '1';
            this.elements.statusIndicator.className = isError ? 'status-indicator error' : 'status-indicator';
            
            if (temporary) {
                this.statusTimeout = setTimeout(() => {
                    if (this.elements.statusIndicator) {
                        this.elements.statusIndicator.style.opacity = '0';
                    }
                }, 3000);
            }
        } catch (error) {
            console.error('Status update failed:', error);
        }
    }

    async initAudioContext() {
        try {
            this.updateStatus('Initializing audio system...');
            
            const AudioContextClass = window.AudioContext || window.webkitAudioContext;
            if (!AudioContextClass) {
                throw new Error('Web Audio API not supported in this browser');
            }
            
            // Close existing context if it exists
            if (this.audioContext && this.audioContext.state !== 'closed') {
                await this.audioContext.close();
            }
            
            this.audioContext = new AudioContextClass({
                sampleRate: 44100,
                latencyHint: 'interactive'
            });
            
            this.analyser = this.audioContext.createAnalyser();
            this.gainNode = this.audioContext.createGain();
            
            this.analyser.fftSize = CONSTANTS.AUDIO_FFT_SIZE;
            this.analyser.smoothingTimeConstant = 0.85;
            this.analyser.minDecibels = -90;
            this.analyser.maxDecibels = -10;

            this.gainNode.connect(this.analyser);
            this.gainNode.gain.setValueAtTime(1.0, this.audioContext.currentTime);

            // Handle audio context state changes
            this.audioContext.addEventListener('statechange', () => {
                console.log('Audio context state changed to:', this.audioContext.state);
                if (this.audioContext.state === 'suspended') {
                    this.updateStatus('Audio suspended - click to resume', true);
                }
            });

            // Resume if suspended
            if (this.audioContext.state === 'suspended') {
                await this.audioContext.resume();
            }

            this.isAudioInitialized = true;
            this.updateStatus('Audio system ready - Click "Start Microphone" to begin', true);
            console.log('Audio system initialized successfully');
            
        } catch (error) {
            console.error('Audio initialization failed:', error);
            this.updateStatus(`Audio initialization failed: ${error.message}`, true, true);
            this.isAudioInitialized = false;
            throw error;
        }
    }

    async toggleMicrophone() {
        try {
            if (!this.isAudioInitialized) {
                await this.initAudioContext();
                if (!this.isAudioInitialized) return;
            }
            
            if (!this.usingMic) {
                await this.startMicrophone();
            } else {
                this.stopMicrophone();
            }
        } catch (error) {
            console.error('Microphone toggle failed:', error);
            this.updateStatus(`Microphone error: ${error.message}`, true, true);
        }
    }

    async startMicrophone() {
        try {
            this.updateStatus('Requesting microphone access...');
            this.elements.micToggle.disabled = true;
            
            if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
                throw new Error('Microphone access not supported in this browser');
            }

            // Enhanced audio constraints with fallbacks
            const constraints = {
                audio: {
                    echoCancellation: false,
                    noiseSuppression: false,
                    autoGainControl: false,
                    sampleRate: { ideal: 44100, min: 22050 },
                    channelCount: { ideal: 1 },
                    latency: { ideal: 0.01 }
                }
            };

            try {
                this.micStream = await navigator.mediaDevices.getUserMedia(constraints);
            } catch (error) {
                // Fallback with basic constraints
                console.warn('Failed with enhanced constraints, trying basic:', error);
                this.micStream = await navigator.mediaDevices.getUserMedia({ audio: true });
            }

            if (this.audioContext.state === 'suspended') {
                await this.audioContext.resume();
            }

            this.micSource = this.audioContext.createMediaStreamSource(this.micStream);
            this.micSource.connect(this.gainNode);

            this.usingMic = true;
            this.elements.micToggle.textContent = 'Stop Microphone';
            this.elements.micToggle.disabled = false;
            this.updateStatus('Microphone active - visualization running', true);
            
        } catch (error) {
            console.error('Microphone access failed:', error);
            this.elements.micToggle.disabled = false;
            
            let errorMessage = 'Microphone access failed';
            if (error.name === 'NotAllowedError') {
                errorMessage = 'Microphone permission denied - please allow access and try again';
            } else if (error.name === 'NotFoundError') {
                errorMessage = 'No microphone found - please connect a microphone';
            } else if (error.name === 'NotReadableError') {
                errorMessage = 'Microphone is being used by another application';
            } else if (error.name === 'OverconstrainedError') {
                errorMessage = 'Microphone constraints not supported';
            }
            this.updateStatus(errorMessage, true, true);
            throw error;
        }
    }

    stopMicrophone() {
        try {
            if (this.micSource) {
                this.micSource.disconnect();
                this.micSource = null;
            }
            
            if (this.micStream) {
                this.micStream.getTracks().forEach(track => {
                    track.stop();
                });
                this.micStream = null;
            }
            
            this.usingMic = false;
            this.elements.micToggle.textContent = 'Start Microphone';
            this.elements.micToggle.disabled = false;
            this.updateStatus('Microphone stopped', true);
        } catch (error) {
            console.error('Failed to stop microphone:', error);
        }
    }

    updateGain(event) {
        try {
            const value = parseFloat(event.target.value);
            if (isNaN(value)) return;
            
            const clampedValue = Math.max(0.1, Math.min(value, 5.0));
            this.elements.gainLabel.textContent = `Gain: ${clampedValue.toFixed(1)}x`;
            
            if (this.gainNode && this.audioContext) {
                this.gainNode.gain.setValueAtTime(clampedValue, this.audioContext.currentTime);
            }
        } catch (error) {
            console.error('Gain control failed:', error);
        }
    }

    getAudioData(sphere) {
        if (!this.analyser || !this.isAudioInitialized || !this.usingMic || this.isDestroyed) {
            return { 
                average: 0, 
                frequencies: new Uint8Array(1024), 
                peakDetected: false,
                rangeEnergy: 0,
                rangeEnergyBeat: 0
            };
        }
        
        try {
            const frequencies = new Uint8Array(this.analyser.frequencyBinCount);
            this.analyser.getByteFrequencyData(frequencies);

            const nyquist = this.audioContext.sampleRate / 2;
            const frequencyToIndex = (frequency) => {
                return Math.round(Math.max(0, Math.min(frequency, nyquist)) / nyquist * this.analyser.frequencyBinCount);
            };

            // Validate frequency ranges
            const minFreq = Math.max(0, Math.min(sphere.params.minFrequency, sphere.params.maxFrequency));
            const maxFreq = Math.max(minFreq + 1, sphere.params.maxFrequency);
            
            const minBeatFreq = Math.max(0, Math.min(sphere.params.minFrequencyBeat, sphere.params.maxFrequencyBeat));
            const maxBeatFreq = Math.max(minBeatFreq + 1, sphere.params.maxFrequencyBeat);

            // Calculate visualization energy
            const minIndex = frequencyToIndex(minFreq);
            const maxIndex = frequencyToIndex(maxFreq);
            const rangeLength = Math.max(1, maxIndex - minIndex + 1);
            
            let rangeSum = 0;
            for (let i = minIndex; i <= maxIndex; i++) {
                rangeSum += frequencies[i] || 0;
            }
            const rangeEnergy = rangeSum / rangeLength;

            // Calculate beat energy
            const minBeatIndex = frequencyToIndex(minBeatFreq);
            const maxBeatIndex = frequencyToIndex(maxBeatFreq);
            const beatLength = Math.max(1, maxBeatIndex - minBeatIndex + 1);
            
            let beatSum = 0;
            for (let i = minBeatIndex; i <= maxBeatIndex; i++) {
                beatSum += frequencies[i] || 0;
            }
            const rangeEnergyBeat = beatSum / beatLength;

            // Peak detection with improved algorithm
            if (!sphere.peakDetection) {
                sphere.peakDetection = {
                    energyHistory: [],
                    historyLength: CONSTANTS.BEAT_HISTORY_LENGTH,
                    lastPeakTime: 0,
                    minTimeBetweenPeaks: CONSTANTS.MIN_PEAK_INTERVAL
                };
            }

            sphere.peakDetection.energyHistory.push(rangeEnergy);
            if (sphere.peakDetection.energyHistory.length > sphere.peakDetection.historyLength) {
                sphere.peakDetection.energyHistory.shift();
            }
            
            const averageEnergy = sphere.peakDetection.energyHistory.length > 0 ? 
                sphere.peakDetection.energyHistory.reduce((a, b) => a + b, 0) / sphere.peakDetection.energyHistory.length : 0;
            
            const now = performance.now();
            const peakSensitivity = Math.max(1.01, sphere.params.peakSensitivity || 1.15);
            const peakDetected = rangeEnergy > averageEnergy * peakSensitivity &&
                               rangeEnergy > 10 && // Minimum threshold
                               now - sphere.peakDetection.lastPeakTime > sphere.peakDetection.minTimeBetweenPeaks;
            
            if (peakDetected) {
                sphere.peakDetection.lastPeakTime = now;
            }

            return {
                average: Math.max(0, Math.min(1, rangeEnergy / 255)),
                frequencies,
                peakDetected,
                rangeEnergy: Math.max(0, rangeEnergy),
                rangeEnergyBeat: Math.max(0, rangeEnergyBeat)
            };

        } catch (error) {
            console.error("Audio analysis failed:", error);
            return { 
                average: 0, 
                frequencies: new Uint8Array(1024), 
                peakDetected: false,
                rangeEnergy: 0,
                rangeEnergyBeat: 0
            };
        }
    }

    createSpheres() {
        try {
            const defaultFrequencies = [
                { minFrequency: 20, maxFrequency: 80 },     // Sub-bass
                { minFrequency: 80, maxFrequency: 250 },    // Bass
                { minFrequency: 250, maxFrequency: 800 },   // Mid
                { minFrequency: 800, maxFrequency: 4000 },  // High mid
                { minFrequency: 4000, maxFrequency: 16000 } // High
            ];

            const colors = [
                { start: '#ff3366', end: '#3366ff' },
                { start: '#ff6633', end: '#ff3366' },
                { start: '#33ff66', end: '#6633ff' },
                { start: '#3366ff', end: '#33ff66' },
                { start: '#6633ff', end: '#ff6633' }
            ];

            for (let i = 0; i < CONSTANTS.MAX_SPHERES; i++) {
                if (this.isDestroyed) break;
                
                try {
                    const sphere = this.createSphere(i, defaultFrequencies[i], colors[i]);
                    if (sphere) {
                        this.spheres.push(sphere);
                        this.defaultParams.push(JSON.parse(JSON.stringify(sphere.params)));
                    }
                } catch (error) {
                    console.error(`Failed to create sphere ${i}:`, error);
                }
            }
        } catch (error) {
            console.error('Failed to create spheres:', error);
        }
    }

    createSphere(index, frequencies, colors) {
        try {
            const params = {
                enabled: index === 0,
                sphereRadius: 1.2,
                innerSphereRadius: 0.2,
                rotationSpeed: 0.002,
                rotationSpeedMin: 0,
                rotationSpeedMax: 0.08,
                rotationSmoothness: 0.25,
                particleCount: 25000,
                particleSize: 0.015,
                particleLifetime: 4.0,
                minFrequency: frequencies?.minFrequency || 0,
                maxFrequency: frequencies?.maxFrequency || 22050,
                minFrequencyBeat: frequencies?.minFrequency || 0,
                maxFrequencyBeat: frequencies?.maxFrequency || 22050,
                noiseScale: 3.5,
                dynamicNoiseScale: true,
                minNoiseScale: 1.0,
                maxNoiseScale: 6.0,
                noiseStep: 0.3,
                noiseSpeed: 0.15,
                turbulenceStrength: 0.008,
                colorStart: colors?.start || '#ff3366',
                colorEnd: colors?.end || '#3366ff',
                volumeChangeThreshold: 0.08,
                peakSensitivity: 1.15,
                beatThreshold: 180,
                baseWaveStrength: 25.0,
                beatStrength: 0.015,
            };

            // Validate and fix parameters
            params.particleCount = Math.max(CONSTANTS.MIN_PARTICLES, Math.min(params.particleCount, CONSTANTS.MAX_PARTICLES));
            
            if (params.minNoiseScale >= params.maxNoiseScale) {
                params.maxNoiseScale = params.minNoiseScale + 0.1;
            }
            
            if (params.minFrequency >= params.maxFrequency) {
                params.maxFrequency = params.minFrequency + 1;
            }
            
            if (params.minFrequencyBeat >= params.maxFrequencyBeat) {
                params.maxFrequencyBeat = params.minFrequencyBeat + 1;
            }

            const sphere = new SphereVisualization(index, params, this.scene, this.mainGui, this);
            return sphere;
        } catch (error) {
            console.error(`Failed to create sphere ${index}:`, error);
            return null;
        }
    }

    reinitializeParticles(sphere) {
        try {
            if (!sphere || this.isDestroyed) return;
            
            sphere.initializeParticles();
            sphere.updateColors();
        } catch (error) {
            console.error('Failed to reinitialize particles:', error);
        }
    }

    // Preset management
    loadPresets() {
        try {
            const stored = localStorage.getItem('audioVisualizerPresets');
            this.presets = stored ? JSON.parse(stored) : {};
            this.updatePresetOptions();
        } catch (error) {
            console.error('Failed to load presets:', error);
            this.presets = {};
        }
    }

    savePreset() {
        try {
            const presetName = this.elements.presetInput.value.trim();
            if (!presetName) {
                this.updateStatus('Please enter a preset name', true, true);
                return;
            }
            
            if (presetName.length > 50) {
                this.updateStatus('Preset name too long (max 50 characters)', true, true);
                return;
            }
            
            this.presets[presetName] = this.spheres.map(sphere => {
                if (!sphere?.params) return null;
                return JSON.parse(JSON.stringify(sphere.params));
            }).filter(p => p !== null);
            
            localStorage.setItem('audioVisualizerPresets', JSON.stringify(this.presets));
            this.updatePresetOptions();
            this.elements.presetInput.value = '';
            this.updateStatus(`Preset "${presetName}" saved`, true);
        } catch (error) {
            console.error('Failed to save preset:', error);
            this.updateStatus('Failed to save preset', true, true);
        }
    }

    resetToDefaults() {
        try {
            if (!this.spheres || !this.defaultParams) return;
            
            this.spheres.forEach((sphere, index) => {
                if (!sphere?.params || !this.defaultParams[index]) return;
                
                const previousParticleCount = sphere.params.particleCount;
                Object.assign(sphere.params, JSON.parse(JSON.stringify(this.defaultParams[index])));
                sphere.particleSystem.visible = sphere.params.enabled;

                if (sphere.params.particleCount !== previousParticleCount) {
                    this.reinitializeParticles(sphere);
                }

                sphere.updateColors();
            });

            if (this.mainGui) {
                this.mainGui.updateDisplay();
            }
            this.updateStatus('Reset to default parameters', true);
        } catch (error) {
            console.error('Failed to reset:', error);
            this.updateStatus('Failed to reset parameters', true, true);
        }
    }

    deletePreset() {
        try {
            const presetName = this.elements.presetSelect.value;
            if (!presetName) {
                this.updateStatus('No preset selected', true, true);
                return;
            }

            if (confirm(`Delete preset "${presetName}"?`)) {
                delete this.presets[presetName];
                localStorage.setItem('audioVisualizerPresets', JSON.stringify(this.presets));
                this.updatePresetOptions();
                this.elements.presetSelect.value = '';
                this.updateStatus(`Preset "${presetName}" deleted`, true);
            }
        } catch (error) {
            console.error('Failed to delete preset:', error);
            this.updateStatus('Failed to delete preset', true, true);
        }
    }

    exportPresets() {
        try {
            if (Object.keys(this.presets).length === 0) {
                this.updateStatus('No presets to export', true, true);
                return;
            }
            
            const presetData = JSON.stringify(this.presets, null, 2);
            const blob = new Blob([presetData], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = `audio_visualizer_presets_${new Date().toISOString().slice(0, 10)}.json`;
            link.style.display = 'none';
            
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            
            // Clean up the URL after a delay
            setTimeout(() => URL.revokeObjectURL(url), 1000);
            
            this.updateStatus('Presets exported', true);
        } catch (error) {
            console.error('Export failed:', error);
            this.updateStatus('Export failed', true, true);
        }
    }

    importPresets() {
        try {
            const fileInput = document.createElement('input');
            fileInput.type = 'file';
            fileInput.accept = '.json';
            fileInput.style.display = 'none';
            
            fileInput.onchange = (event) => {
                const file = event.target.files[0];
                if (!file) return;
                
                if (file.size > 1024 * 1024) { // 1MB limit
                    this.updateStatus('File too large (max 1MB)', true, true);
                    return;
                }
                
                const reader = new FileReader();
                reader.onload = (e) => {
                    try {
                        const importedPresets = JSON.parse(e.target.result);
                        if (typeof importedPresets === 'object' && importedPresets !== null) {
                            // Validate preset structure
                            let validPresets = 0;
                            Object.entries(importedPresets).forEach(([name, preset]) => {
                                if (Array.isArray(preset) && preset.length > 0) {
                                    this.presets[name] = preset;
                                    validPresets++;
                                }
                            });
                            
                            if (validPresets > 0) {
                                localStorage.setItem('audioVisualizerPresets', JSON.stringify(this.presets));
                                this.updatePresetOptions();
                                this.updateStatus(`${validPresets} presets imported successfully`, true);
                            } else {
                                this.updateStatus('No valid presets found in file', true, true);
                            }
                        } else {
                            throw new Error('Invalid preset format');
                        }
                    } catch (error) {
                        console.error('Error importing presets:', error);
                        this.updateStatus('Error importing presets: Invalid format', true, true);
                    }
                };
                
                reader.onerror = () => {
                    this.updateStatus('Error reading file', true, true);
                };
                
                reader.readAsText(file);
                document.body.removeChild(fileInput);
            };
            
            document.body.appendChild(fileInput);
            fileInput.click();
        } catch (error) {
            console.error('Import failed:', error);
            this.updateStatus('Import failed', true, true);
        }
    }

    loadPreset() {
        try {
            const presetName = this.elements.presetSelect.value;
            if (!presetName || !this.presets[presetName]) return;

            const preset = this.presets[presetName];
            
            this.spheres.forEach((sphere, index) => {
                if (!sphere?.params || !preset[index]) return;
                
                const previousParticleCount = sphere.params.particleCount;
                const newParams = JSON.parse(JSON.stringify(preset[index]));
                
                // Ensure backward compatibility and validate parameters
                if (!('minFrequencyBeat' in newParams)) {
                    newParams.minFrequencyBeat = newParams.minFrequency;
                }
                if (!('maxFrequencyBeat' in newParams)) {
                    newParams.maxFrequencyBeat = newParams.maxFrequency;
                }
                
                // Validate ranges
                if (newParams.minNoiseScale >= newParams.maxNoiseScale) {
                    newParams.maxNoiseScale = newParams.minNoiseScale + 0.1;
                }
                
                if (newParams.minFrequency >= newParams.maxFrequency) {
                    newParams.maxFrequency = newParams.minFrequency + 1;
                }
                
                if (newParams.minFrequencyBeat >= newParams.maxFrequencyBeat) {
                    newParams.maxFrequencyBeat = newParams.minFrequencyBeat + 1;
                }
                
                // Validate particle count
                newParams.particleCount = Math.max(CONSTANTS.MIN_PARTICLES, 
                    Math.min(newParams.particleCount, CONSTANTS.MAX_PARTICLES));

                Object.assign(sphere.params, newParams);

                if (sphere.params.particleCount !== previousParticleCount) {
                    this.reinitializeParticles(sphere);
                }

                sphere.particleSystem.visible = sphere.params.enabled;
                sphere.updateColors();
            });

            if (this.mainGui) {
                this.mainGui.updateDisplay();
            }
            this.updateStatus(`Preset "${presetName}" loaded`, true);
        } catch (error) {
            console.error('Failed to load preset:', error);
            this.updateStatus('Failed to load preset', true, true);
        }
    }

    updatePresetOptions() {
        try {
            if (!this.elements.presetSelect) return;
            
            this.elements.presetSelect.innerHTML = '<option value="">Select preset...</option>';
            
            Object.keys(this.presets).sort().forEach(name => {
                const option = document.createElement('option');
                option.textContent = name;
                option.value = name;
                this.elements.presetSelect.appendChild(option);
            });
        } catch (error) {
            console.error('Failed to update preset options:', error);
        }
    }

    handleResize() {
        try {
            if (this.isDestroyed || !this.renderer || !this.camera) return;
            
            const width = window.innerWidth;
            const height = window.innerHeight;
            
            this.renderer.setSize(width, height);
            this.camera.aspect = width / height;
            this.camera.updateProjectionMatrix();
        } catch (error) {
            console.error('Resize handler error:', error);
        }
    }

    handleVisibilityChange() {
        try {
            if (document.hidden) {
                // Page is hidden, pause or reduce activity
                if (this.usingMic) {
                    console.log('Page hidden, continuing visualization');
                }
            } else {
                // Page is visible, resume full activity
                if (this.audioContext && this.audioContext.state === 'suspended') {
                    this.audioContext.resume().catch(console.error);
                }
            }
        } catch (error) {
            console.error('Visibility change handler error:', error);
        }
    }

    handleWebGLContextLost(event) {
        try {
            console.warn('WebGL context lost');
            event.preventDefault();
            this.updateStatus('Graphics context lost - attempting recovery...', true, true);
            
            // Cancel animation frame
            if (this.animationId) {
                cancelAnimationFrame(this.animationId);
                this.animationId = null;
            }
        } catch (error) {
            console.error('WebGL context lost handler error:', error);
        }
    }

    handleWebGLContextRestored() {
        try {
            console.log('WebGL context restored');
            this.updateStatus('Graphics context restored', true);
            
            // Restart animation
            this.animate();
        } catch (error) {
            console.error('WebGL context restored handler error:', error);
        }
    }

    handleDocumentClick(event) {
        try {
            const isControlClick = event.target.closest('.dg') || 
                                  event.target.closest('#presetContainer') ||
                                  event.target.closest('.audio-controls');
                                  
            if (!isControlClick) {
                this.toggleControls();
            }
        } catch (error) {
            console.error('Click handler error:', error);
        }
    }

    handleKeyboard(event) {
        try {
            // Prevent default for handled keys
            switch (event.code) {
                case 'Space':
                    event.preventDefault();
                    this.toggleMicrophone();
                    break;
                case 'KeyH':
                    if (event.ctrlKey || event.metaKey) {
                        event.preventDefault();
                        this.toggleControls();
                    }
                    break;
                case 'KeyR':
                    if (event.ctrlKey || event.metaKey) {
                        event.preventDefault();
                        this.resetToDefaults();
                    }
                    break;
            }
        } catch (error) {
            console.error('Keyboard handler error:', error);
        }
    }

    toggleControls() {
        try {
            this.controlsVisible = !this.controlsVisible;
            
            const elements = [
                this.elements.audioControls, 
                this.elements.presetContainer, 
                this.mainGui?.domElement
            ];
            
            elements.forEach(element => {
                if (element && element.style) {
                    element.style.display = this.controlsVisible ? 'block' : 'none';
                }
            });
            
            const action = this.controlsVisible ? 'shown' : 'hidden';
            this.updateStatus(`Controls ${action} (Space: mic, Ctrl+H: toggle controls)`, true);
        } catch (error) {
            console.error('Toggle controls error:', error);
        }
    }

    animate(currentTime = 0) {
        if (this.isDestroyed) return;
        
        this.animationId = requestAnimationFrame((time) => this.animate(time));
        
        const deltaTime = this.lastTime ? Math.min((currentTime - this.lastTime) / 1000, CONSTANTS.ANIMATION_MAX_DELTA) : 0;
        this.lastTime = currentTime;

        try {
            if (!this.renderer || !this.scene || !this.camera) return;
            
            this.beatManager.update(deltaTime);

            this.spheres.forEach(sphere => {
                if (!sphere?.params?.enabled || !sphere.particleSystem) return;

                try {
                    const audioData = this.getAudioData(sphere);

                    // Peak detection and dynamic noise
                    if (audioData.peakDetected && sphere.params.dynamicNoiseScale) {
                        sphere.params.noiseScale = this.generateNewNoiseScale(sphere.params, sphere.lastNoiseScale);
                        sphere.lastNoiseScale = sphere.params.noiseScale;
                    }

                    // Beat detection
                    const beatDetected = audioData.rangeEnergyBeat > sphere.params.beatThreshold;
                    if (beatDetected && !this.beatManager.isWaveActive && sphere.params.beatStrength > 0) {
                        this.beatManager.triggerWave(audioData.rangeEnergyBeat);
                    }

                    // Update sphere
                    sphere.update(audioData, deltaTime, currentTime, beatDetected, this.beatManager);
                } catch (error) {
                    console.error(`Sphere ${sphere.index} update error:`, error);
                }
            });

            this.renderer.render(this.scene, this.camera);
        } catch (error) {
            console.error('Animation loop error:', error);
        }
    }

    generateNewNoiseScale(params, lastNoiseScale) {
        try {
            if (!params.dynamicNoiseScale) {
                return params.noiseScale;
            }

            const { minNoiseScale, maxNoiseScale, noiseStep } = params;

            if (minNoiseScale >= maxNoiseScale) {
                return lastNoiseScale;
            }

            const range = maxNoiseScale - minNoiseScale;
            if (range < 0.1) {
                return lastNoiseScale;
            }

            const adjustedStep = Math.min(noiseStep, range / 2);
            const clampedLastScale = Math.max(minNoiseScale, Math.min(lastNoiseScale, maxNoiseScale));

            const stepsUp = Math.floor((maxNoiseScale - clampedLastScale) / adjustedStep);
            const stepsDown = Math.floor((clampedLastScale - minNoiseScale) / adjustedStep);

            if (stepsUp === 0 && stepsDown === 0) {
                return clampedLastScale;
            }

            const direction = Math.random() < 0.5 && stepsDown > 0 ? -1 : 1;
            const maxSteps = direction === 1 ? stepsUp : stepsDown;
            const steps = Math.floor(Math.random() * (maxSteps + 1));

            const newValue = clampedLastScale + direction * steps * adjustedStep;
            return Math.max(minNoiseScale, Math.min(newValue, maxNoiseScale));
        } catch (error) {
            console.error('Noise scale generation error:', error);
            return params.noiseScale;
        }
    }

    cleanup() {
        try {
            if (this.isDestroyed) return;
            this.isDestroyed = true;
            
            console.log('Cleaning up Audio Visualizer...');
            
            // Cancel animation
            if (this.animationId) {
                cancelAnimationFrame(this.animationId);
                this.animationId = null;
            }
            
            // Stop microphone
            this.stopMicrophone();
            
            // Close audio context
            if (this.audioContext && this.audioContext.state !== 'closed') {
                this.audioContext.close().catch(console.error);
                this.audioContext = null;
            }
            
            // Clear timeouts
            if (this.statusTimeout) {
                clearTimeout(this.statusTimeout);
                this.statusTimeout = null;
            }
            
            if (this.resizeTimeout) {
                clearTimeout(this.resizeTimeout);
                this.resizeTimeout = null;
            }

            // Dispose Three.js objects
            this.spheres.forEach(sphere => {
                try {
                    if (sphere.geometry) sphere.geometry.dispose();
                    if (sphere.material) sphere.material.dispose();
                    if (sphere.particleSystem) this.scene.remove(sphere.particleSystem);
                } catch (error) {
                    console.error('Sphere cleanup error:', error);
                }
            });
            this.spheres = [];

            // Dispose scene objects
            if (this.scene) {
                this.scene.traverse((object) => {
                    if (object.geometry) object.geometry.dispose();
                    if (object.material) {
                        if (Array.isArray(object.material)) {
                            object.material.forEach(material => material.dispose());
                        } else {
                            object.material.dispose();
                        }
                    }
                });
                this.scene = null;
            }

            // Dispose renderer
            if (this.renderer) {
                this.renderer.dispose();
                if (this.renderer.domElement && this.renderer.domElement.parentNode) {
                    this.renderer.domElement.parentNode.removeChild(this.renderer.domElement);
                }
                this.renderer = null;
            }

            // Destroy GUI
            if (this.mainGui) {
                this.mainGui.destroy();
                this.mainGui = null;
            }

            // Remove event listeners
            document.removeEventListener('visibilitychange', this.handleVisibilityChange);
            
            // Remove DOM elements
            Object.values(this.elements).forEach(element => {
                try {
                    if (element && element.parentNode) {
                        element.parentNode.removeChild(element);
                    }
                } catch (error) {
                    console.error('Element cleanup error:', error);
                }
            });
            this.elements = {};

            // Remove styles
            const styles = document.getElementById('audio-visualizer-styles');
            if (styles) {
                styles.remove();
            }

            console.log('Audio Visualizer cleanup complete');
        } catch (error) {
            console.error('Cleanup error:', error);
        }
    }
}

class BeatManager {
    constructor() {
        this.currentWaveRadius = 0;
        this.waveStrength = 0;
        this.isWaveActive = false;
        this.waveDecay = 0.96;
        this.maxWaveRadius = 2;
    }
    
    triggerWave(energy) {
        try {
            this.waveStrength = Math.min(Math.max(0, energy) / 50, 25);
            this.currentWaveRadius = 0;
            this.isWaveActive = true;
        } catch (error) {
            console.error('Wave trigger error:', error);
        }
    }
    
    update(deltaTime) {
        try {
            if (this.isWaveActive) {
                this.currentWaveRadius += Math.max(0, deltaTime) * 2;
                this.waveStrength *= this.waveDecay;
                
                if (this.currentWaveRadius > this.maxWaveRadius || this.waveStrength < 0.1) {
                    this.isWaveActive = false;
                }
            }
        } catch (error) {
            console.error('Beat manager update error:', error);
        }
    }
    
    getWaveForce(position) {
        try {
            if (!this.isWaveActive || !position) return 0;
            
            const distanceFromCenter = position.length();
            const distanceFromWave = Math.abs(distanceFromCenter - this.currentWaveRadius);
            
            if (distanceFromWave < 0.2) {
                return this.waveStrength * Math.exp(-distanceFromWave * 8);
            }
            return 0;
        } catch (error) {
            console.error('Wave force calculation error:', error);
            return 0;
        }
    }
}

class NoiseGenerator {
    constructor() {
        this.p = new Array(CONSTANTS.NOISE_PERMUTATION_SIZE).fill(0).map((_, i) => i);
        this.perm = new Array(CONSTANTS.NOISE_PERMUTATION_SIZE * 2);
        this.init();
    }
    
    init() {
        try {
            // Fisher-Yates shuffle
            for (let i = this.p.length - 1; i > 0; i--) {
                const j = Math.floor(Math.random() * (i + 1));
                [this.p[i], this.p[j]] = [this.p[j], this.p[i]];
            }
            // Double the permutation array
            for (let i = 0; i < CONSTANTS.NOISE_PERMUTATION_SIZE * 2; i++) {
                this.perm[i] = this.p[i & (CONSTANTS.NOISE_PERMUTATION_SIZE - 1)];
            }
        } catch (error) {
            console.error('Noise generator initialization error:', error);
        }
    }
    
    fade(t) { 
        return t * t * t * (t * (t * 6 - 15) + 10); 
    }
    
    lerp(t, a, b) { 
        return a + t * (b - a); 
    }
    
    grad(hash, x, y, z) {
        const h = hash & 15;
        const u = h < 8 ? x : y;
        const v = h < 4 ? y : h === 12 || h === 14 ? x : z;
        return ((h & 1) === 0 ? u : -u) + ((h & 2) === 0 ? v : -v);
    }
    
    noise3D(x, y, z) {
        try {
            if (!isFinite(x) || !isFinite(y) || !isFinite(z)) return 0;
            
            const X = Math.floor(x) & (CONSTANTS.NOISE_PERMUTATION_SIZE - 1);
            const Y = Math.floor(y) & (CONSTANTS.NOISE_PERMUTATION_SIZE - 1);
            const Z = Math.floor(z) & (CONSTANTS.NOISE_PERMUTATION_SIZE - 1);
            
            x -= Math.floor(x);
            y -= Math.floor(y);
            z -= Math.floor(z);
            
            const u = this.fade(x);
            const v = this.fade(y);
            const w = this.fade(z);
            
            const A = this.perm[X] + Y;
            const AA = this.perm[A] + Z;
            const AB = this.perm[A + 1] + Z;
            const B = this.perm[X + 1] + Y;
            const BA = this.perm[B] + Z;
            const BB = this.perm[B + 1] + Z;
            
            return this.lerp(w, 
                this.lerp(v, 
                    this.lerp(u, this.grad(this.perm[AA], x, y, z),
                              this.grad(this.perm[BA], x-1, y, z)),
                    this.lerp(u, this.grad(this.perm[AB], x, y-1, z),
                              this.grad(this.perm[BB], x-1, y-1, z))),
                this.lerp(v, 
                    this.lerp(u, this.grad(this.perm[AA+1], x, y, z-1),
                              this.grad(this.perm[BA+1], x-1, y, z-1)),
                    this.lerp(u, this.grad(this.perm[AB+1], x, y-1, z-1),
                              this.grad(this.perm[BB+1], x-1, y-1, z-1))));
        } catch (error) {
            console.error('3D noise calculation error:', error);
            return 0;
        }
    }
}

class SphereVisualization {
    constructor(index, params, scene, gui, visualizer) {
        this.index = index;
        this.params = params;
        this.scene = scene;
        this.gui = gui;
        this.visualizer = visualizer;
        this.lastNoiseScale = params.noiseScale;
        this.lastValidVolume = 0;
        this.lastRotationSpeed = 0;
        
        this.peakDetection = {
            energyHistory: [],
            historyLength: CONSTANTS.BEAT_HISTORY_LENGTH,
            lastPeakTime: 0,
            minTimeBetweenPeaks: CONSTANTS.MIN_PEAK_INTERVAL
        };
        
        try {
            this.initializeGeometry();
            this.initializeParticles();
            this.createMaterial();
            this.createParticleSystem();
            this.setupGUI();
            this.updateColors();
        } catch (error) {
            console.error(`Sphere ${index} initialization failed:`, error);
            throw error;
        }
    }

    initializeGeometry() {
        try {
            if (this.geometry) {
                this.geometry.dispose();
            }
            this.geometry = new THREE.BufferGeometry();
        } catch (error) {
            console.error('Geometry initialization failed:', error);
            throw error;
        }
    }

    initializeParticles() {
        try {
            const count = Math.max(CONSTANTS.MIN_PARTICLES, Math.min(this.params.particleCount, CONSTANTS.MAX_PARTICLES));
            
            this.positions = new Float32Array(count * 3);
            this.colors = new Float32Array(count * 3);
            this.velocities = new Float32Array(count * 3);
            this.basePositions = new Float32Array(count * 3);
            this.lifetimes = new Float32Array(count);
            this.maxLifetimes = new Float32Array(count);
            this.beatEffects = new Float32Array(count);
            
            const radius = Math.max(0.1, this.params.sphereRadius);
            const innerRadius = Math.max(0, Math.min(this.params.innerSphereRadius, radius - 0.1));
            const lifetime = Math.max(0.1, this.params.particleLifetime);
            
            for (let i = 0; i < count; i++) {
                const i3 = i * 3;
                
                // Improved spherical distribution
                const theta = Math.random() * Math.PI * 2;
                const phi = Math.acos(2 * Math.random() - 1);
                const r = Math.pow(Math.random(), 1/3) * THREE.MathUtils.lerp(innerRadius, radius, Math.random());

                const x = r * Math.sin(phi) * Math.cos(theta);
                const y = r * Math.sin(phi) * Math.sin(theta);
                const z = r * Math.cos(phi);

                this.positions[i3] = x;
                this.positions[i3 + 1] = y;
                this.positions[i3 + 2] = z;

                this.basePositions[i3] = x;
                this.basePositions[i3 + 1] = y;
                this.basePositions[i3 + 2] = z;

                this.velocities[i3] = 0;
                this.velocities[i3 + 1] = 0;
                this.velocities[i3 + 2] = 0;

                const lt = Math.random() * lifetime;
                this.lifetimes[i] = lt;
                this.maxLifetimes[i] = lt;
                this.beatEffects[i] = 0;
            }

            this.geometry.setAttribute('position', new THREE.BufferAttribute(this.positions, 3));
            this.geometry.setAttribute('color', new THREE.BufferAttribute(this.colors, 3));
        } catch (error) {
            console.error('Particle initialization failed:', error);
            throw error;
        }
    }

    createMaterial() {
        try {
            if (this.material) {
                this.material.dispose();
            }
            
            this.material = new THREE.PointsMaterial({
                size: Math.max(0.001, this.params.particleSize),
                vertexColors: true,
                transparent: true,
                opacity: 0.9,
                blending: THREE.AdditiveBlending,
                fog: true,
                sizeAttenuation: true,
                alphaTest: 0.001
            });
        } catch (error) {
            console.error('Material creation failed:', error);
            throw error;
        }
    }

    createParticleSystem() {
        try {
            if (this.particleSystem) {
                this.scene.remove(this.particleSystem);
            }
            
            this.particleSystem = new THREE.Points(this.geometry, this.material);
            this.particleSystem.position.x = (this.index - 2) * 0.6;
            this.particleSystem.castShadow = true;
            this.particleSystem.visible = this.params.enabled;
            this.scene.add(this.particleSystem);
        } catch (error) {
            console.error('Particle system creation failed:', error);
            throw error;
        }
    }

    updateColors() {
        try {
            const color1 = new THREE.Color(this.params.colorStart);
            const color2 = new THREE.Color(this.params.colorEnd);
            const count = this.positions ? this.positions.length / 3 : 0;

            for (let i = 0; i < count; i++) {
                const t = count > 1 ? i / (count - 1) : 0;
                const i3 = i * 3;
                
                if (this.colors && i3 + 2 < this.colors.length) {
                    this.colors[i3] = color1.r * (1 - t) + color2.r * t;
                    this.colors[i3 + 1] = color1.g * (1 - t) + color2.g * t;
                    this.colors[i3 + 2] = color1.b * (1 - t) + color2.b * t;
                }
            }
            
            if (this.geometry && this.geometry.attributes.color) {
                this.geometry.attributes.color.needsUpdate = true;
            }
        } catch (error) {
            console.error('Color update failed:', error);
        }
    }

    setupGUI() {
        try {
            if (!this.gui) return;
            
            const sphereFolder = this.gui.addFolder(`Sphere ${this.index + 1}`);
            
            sphereFolder.add(this.params, 'enabled').name('Enabled').onChange(value => {
                if (this.particleSystem) {
                    this.particleSystem.visible = value;
                }
            });

            // Particle settings
            const particleFolder = sphereFolder.addFolder('Particles');
            particleFolder.add(this.params, 'particleCount', CONSTANTS.MIN_PARTICLES, CONSTANTS.MAX_PARTICLES, 1000)
                .name('Count')
                .onChange(() => {
                    this.initializeParticles();
                    this.updateColors();
                });
            
            particleFolder.add(this.params, 'particleSize', 0.005, 0.05, 0.001)
                .name('Size')
                .onChange(value => {
                    if (this.material) {
                        this.material.size = Math.max(0.001, value);
                    }
                });

            particleFolder.add(this.params, 'particleLifetime', 1, 20, 0.5).name('Lifetime');
            
            // Shape settings
            const shapeFolder = sphereFolder.addFolder('Shape');
            shapeFolder.add(this.params, 'sphereRadius', 0.5, 5.0, 0.1).name('Radius');
            shapeFolder.add(this.params, 'innerSphereRadius', 0, 1, 0.05)
                .name('Inner Radius')
                .onChange(() => {
                    this.initializeParticles();
                    this.updateColors();
                });

            // Motion settings
            const motionFolder = sphereFolder.addFolder('Motion');
            motionFolder.add(this.params, 'rotationSpeedMin', 0, 0.02, 0.001).name('Min Rotation');
            motionFolder.add(this.params, 'rotationSpeedMax', 0, 0.1, 0.001).name('Max Rotation');
            motionFolder.add(this.params, 'rotationSmoothness', 0.01, 1, 0.01).name('Smoothness');
            
            // Audio settings
            const audioFolder = sphereFolder.addFolder('Audio');
            audioFolder.add(this.params, 'minFrequency', 0, 22050, 10).name('Min Frequency (Hz)');
            audioFolder.add(this.params, 'maxFrequency', 0, 22050, 10).name('Max Frequency (Hz)');
            audioFolder.add(this.params, 'minFrequencyBeat', 0, 22050, 10).name('Min Beat Freq (Hz)');
            audioFolder.add(this.params, 'maxFrequencyBeat', 0, 22050, 10).name('Max Beat Freq (Hz)');
            audioFolder.add(this.params, 'peakSensitivity', 1.01, 3.0, 0.01).name('Peak Sensitivity');
            audioFolder.add(this.params, 'beatThreshold', 50, 255, 5).name('Beat Threshold');
            audioFolder.add(this.params, 'beatStrength', 0, 0.05, 0.001).name('Beat Strength');
            
            // Noise settings
            const noiseFolder = sphereFolder.addFolder('Noise');
            noiseFolder.add(this.params, 'dynamicNoiseScale').name('Dynamic Scale');
            noiseFolder.add(this.params, 'noiseScale', 0.5, 10.0, 0.1).name('Scale');
            noiseFolder.add(this.params, 'minNoiseScale', 0.5, 10.0, 0.1).name('Min Scale');
            noiseFolder.add(this.params, 'maxNoiseScale', 0.5, 10.0, 0.1).name('Max Scale');
            noiseFolder.add(this.params, 'noiseStep', 0.1, 2.0, 0.1).name('Step');
            noiseFolder.add(this.params, 'noiseSpeed', 0, 1.0, 0.01).name('Speed');
            noiseFolder.add(this.params, 'turbulenceStrength', 0, 0.02, 0.001).name('Turbulence');
            
            // Color settings
            const colorFolder = sphereFolder.addFolder('Colors');
            colorFolder.addColor(this.params, 'colorStart')
                .name('Start Color')
                .onChange(() => this.updateColors());
            colorFolder.addColor(this.params, 'colorEnd')
                .name('End Color')
                .onChange(() => this.updateColors());

            // Copy function for first sphere
            if (this.index === 0) {
                sphereFolder.add({
                    copyToOthers: () => this.copyParametersToOthers()
                }, 'copyToOthers').name('Copy to All Spheres');
            }

            // Close folders by default
            [particleFolder, shapeFolder, motionFolder, audioFolder, noiseFolder, colorFolder, sphereFolder]
                .forEach(folder => folder.close());
        } catch (error) {
            console.error('GUI setup failed:', error);
        }
    }

    copyParametersToOthers() {
        try {
            if (!this.visualizer || !this.visualizer.spheres) return;
            
            for (let i = 1; i < this.visualizer.spheres.length; i++) {
                const targetSphere = this.visualizer.spheres[i];
                if (!targetSphere?.params) continue;
                
                const sourceParams = JSON.parse(JSON.stringify(this.params));
                Object.assign(targetSphere.params, sourceParams);
                
                targetSphere.initializeParticles();
                if (targetSphere.particleSystem) {
                    targetSphere.particleSystem.visible = targetSphere.params.enabled;
                }
                targetSphere.updateColors();
            }
            
            if (this.visualizer.mainGui) {
                this.visualizer.mainGui.updateDisplay();
            }
            this.visualizer.updateStatus('Parameters copied from Sphere 1 to all spheres', true);
        } catch (error) {
            console.error('Failed to copy parameters:', error);
            if (this.visualizer) {
                this.visualizer.updateStatus('Failed to copy parameters', true, true);
            }
        }
    }

    update(audioData, deltaTime, currentTime, beatDetected, beatManager) {
        try {
            if (!this.particleSystem || this.visualizer.isDestroyed) return;
            
            this.updateParticles(audioData, deltaTime, currentTime, beatDetected, beatManager);
            this.updateRotation(audioData);
        } catch (error) {
            console.error(`Sphere ${this.index} update failed:`, error);
        }
    }

    updateParticles(audioData, deltaTime, currentTime, beatDetected, beatManager) {
        try {
            if (!this.positions || !this.velocities || !this.lifetimes) return;
            
            const pc = this.positions.length / 3;
            const ns = Math.max(0.1, this.params.noiseScale);
            const speed = Math.max(0, this.params.noiseSpeed);
            const timeFactor = currentTime * 0.001;
            const turbulence = Math.max(0, this.params.turbulenceStrength);
            const radius = Math.max(0.1, this.params.sphereRadius);
            const innerRadius = Math.max(0, Math.min(this.params.innerSphereRadius, radius - 0.1));
            const lifetime = Math.max(0.1, this.params.particleLifetime);
            const beatStrength = Math.max(0, this.params.beatStrength);

            for (let i = 0; i < pc; i++) {
                const i3 = i * 3;

                if (i3 + 2 >= this.positions.length || i >= this.lifetimes.length) continue;

                let x = this.positions[i3];
                let y = this.positions[i3 + 1];
                let z = this.positions[i3 + 2];

                let vx = this.velocities[i3];
                let vy = this.velocities[i3 + 1];
                let vz = this.velocities[i3 + 2];

                let lt = this.lifetimes[i];
                let be = this.beatEffects[i];

                lt -= Math.max(0, deltaTime);

                // Noise-based movement
                if (this.visualizer.noiseGenerator) {
                    const noiseX = this.visualizer.noiseGenerator.noise3D(x * ns + timeFactor * speed, y * ns, z * ns);
                    const noiseY = this.visualizer.noiseGenerator.noise3D(x * ns, y * ns + timeFactor * speed, z * ns);
                    const noiseZ = this.visualizer.noiseGenerator.noise3D(x * ns, y * ns, z * ns + timeFactor * speed);

                    vx += noiseX * turbulence;
                    vy += noiseY * turbulence;
                    vz += noiseZ * turbulence;
                }

                // Beat effects
                if (beatDetected) {
                    be = 1.0;
                }
                be *= 0.94;

                if (be > 0.01) {
                    const dist = Math.sqrt(x*x + y*y + z*z);
                    if (dist > 0) {
                        const beatForce = be * beatStrength;
                        const invDist = 1 / dist;
                        vx += x * invDist * beatForce;
                        vy += y * invDist * beatForce;
                        vz += z * invDist * beatForce;
                    }
                }

                // Update position
                x += vx;
                y += vy;
                z += vz;

                // Damping
                vx *= 0.97;
                vy *= 0.97;
                vz *= 0.97;

                // Boundary constraints
                const dist = Math.sqrt(x*x + y*y + z*z);
                if (dist > radius) {
                    const overflow = dist - radius;
                    const pullback = overflow * 0.12;
                    if (dist > 0) {
                        const invDist = 1 / dist;
                        x -= x * invDist * pullback;
                        y -= y * invDist * pullback;
                        z -= z * invDist * pullback;
                    }
                    vx *= 0.85;
                    vy *= 0.85;
                    vz *= 0.85;
                }

                // Respawn particles
                if (lt <= 0) {
                    const theta = Math.random() * Math.PI * 2;
                    const phi = Math.acos(2 * Math.random() - 1);
                    const r = Math.pow(Math.random(), 1/3) * THREE.MathUtils.lerp(innerRadius, radius, Math.random());

                    x = r * Math.sin(phi) * Math.cos(theta);
                    y = r * Math.sin(phi) * Math.sin(theta);
                    z = r * Math.cos(phi);

                    vx = vy = vz = 0;
                    
                    const newLt = Math.random() * lifetime;
                    lt = newLt;
                    if (this.maxLifetimes && i < this.maxLifetimes.length) {
                        this.maxLifetimes[i] = newLt;
                    }
                    be = 0;

                    if (this.basePositions && i3 + 2 < this.basePositions.length) {
                        this.basePositions[i3] = x;
                        this.basePositions[i3 + 1] = y;
                        this.basePositions[i3 + 2] = z;
                    }
                }

                // Update arrays
                this.positions[i3] = x;
                this.positions[i3 + 1] = y;
                this.positions[i3 + 2] = z;

                this.velocities[i3] = vx;
                this.velocities[i3 + 1] = vy;
                this.velocities[i3 + 2] = vz;

                this.lifetimes[i] = lt;
                this.beatEffects[i] = be;
            }

            if (this.geometry && this.geometry.attributes.position) {
                this.geometry.attributes.position.needsUpdate = true;
            }
        } catch (error) {
            console.error('Particle update failed:', error);
        }
    }

    updateRotation(audioData) {
        try {
            if (!this.particleSystem || !audioData) return;
            
            const minSpeed = Math.max(0, this.params.rotationSpeedMin);
            const maxSpeed = Math.max(minSpeed, this.params.rotationSpeedMax);
            const smoothness = Math.max(0.01, Math.min(1, this.params.rotationSmoothness));
            
            const targetRotationSpeed = THREE.MathUtils.lerp(minSpeed, maxSpeed, audioData.average);
            
            this.lastRotationSpeed += (targetRotationSpeed - this.lastRotationSpeed) * smoothness;
            this.particleSystem.rotation.y += this.lastRotationSpeed;
        } catch (error) {
            console.error('Rotation update failed:', error);
        }
    }
}

// Initialize the visualizer with error handling
try {
    const audioVisualizer = new AudioVisualizer();
    
    // Global error handler
    window.addEventListener('error', (event) => {
        console.error('Global error:', event.error);
        if (audioVisualizer && audioVisualizer.updateStatus) {
            audioVisualizer.updateStatus('An error occurred - check console', true, true);
        }
    });
    
    // Unhandled promise rejection handler
    window.addEventListener('unhandledrejection', (event) => {
        console.error('Unhandled promise rejection:', event.reason);
        if (audioVisualizer && audioVisualizer.updateStatus) {
            audioVisualizer.updateStatus('Promise error - check console', true, true);
        }
    });
    
} catch (error) {
    console.error('Failed to initialize Audio Visualizer:', error);
    document.body.innerHTML = `
        <div style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); 
                    background: rgba(0,0,0,0.9); color: #FF4444; padding: 20px; border-radius: 10px;
                    font-family: Arial, sans-serif; text-align: center; z-index: 10000;">
            <h2>Audio Visualizer Failed to Load</h2>
            <p>Error: ${error.message}</p>
            <p>Please check the console for more details.</p>
            <button onclick="location.reload()" style="margin-top: 10px; padding: 10px 20px; 
                                                     background: #FF4444; color: white; border: none; 
                                                     border-radius: 5px; cursor: pointer;">
                Reload Page
            </button>
        </div>
    `;
}


